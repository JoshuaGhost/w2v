# License: MIT
"""
Unique version information place
"""

__version__ = "0.0.1"
VERSION = tuple(int(x) for x in __version__.split("."))
